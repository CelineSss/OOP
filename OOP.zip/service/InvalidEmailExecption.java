package service;

public class InvalidEmailExecption extends Exception {
    public InvalidEmailExecption(String message) {
        super(message);
    }
}


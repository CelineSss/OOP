package service;

public class MaxEmailAttemptsExecption extends Exception {
    public MaxEmailAttemptsExecption(String message) {
        super(message);
    }
}

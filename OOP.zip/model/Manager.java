package model;

public class Manager extends User {
    public Manager(String userId, String password, String fullName, String email, String securityKeyword) {
        super(userId, password, fullName, email, securityKeyword);
    }
}
